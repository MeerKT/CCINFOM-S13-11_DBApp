/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeemanagement;
import java.time.*;
import java.sql.*;
import java.util.*;
/**
 *
 * @author katie
 */
public class projects {
    
    // Fields
    public String       project_type;
    public int          employee_ID;
    public int          project_ID;
    public LocalDate    start_date;
    public LocalDate    end_date;
    public LocalDate    project_deadline;
    public String       project_description;
    public String       project_status;
    public String       client;
    
    //list of employees
    public ArrayList<String> project_typeList = new ArrayList<>();
    public ArrayList<Integer> employee_IDList = new ArrayList<>();
    public ArrayList<Integer> project_IDList = new ArrayList<>();
    public ArrayList<LocalDate> start_dateList = new ArrayList<>();
    public ArrayList<LocalDate> end_dateList = new ArrayList<>();
    public ArrayList<LocalDate> project_deadlineList = new ArrayList<>();
    public ArrayList<String> project_statusList = new ArrayList<>();
    public ArrayList<String> clientList = new ArrayList<>();
    
    public int register_project(){
        try {
            Connection  conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/enrolldb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678&useSSL=false"); 
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO projects (project_type, employee_ID, project_ID, start_date, project_deadline,project_status, client) VALUES(?,?,?,?,?,?,?)");
            pstmt.setString(1,project_type);
            pstmt.setInt(2,employee_ID);
            pstmt.setInt(3,project_ID);
            pstmt.setDate(4, java.sql.Date.valueOf(start_date));
            pstmt.setDate(5,java.sql.Date.valueOf(project_deadline));
            pstmt.setString(6, project_status);
            pstmt.setString(7,client);
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    };
    
    public int view_projects(){
        
        try {
            Connection  conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/enrolldb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678&useSSL=false"); 
            PreparedStatement pstmt = conn.prepareStatement("SELECT projectID, project_type, project_status, client, project_deadline FROM projects WHERE project_ID =?");
            pstmt.setInt(1,project_ID);
            pstmt.setString(2,project_type);
            pstmt.setString(3,project_status);
            pstmt.setString(4,client);
            pstmt.setDate(5,java.sql.Date.valueOf(project_deadline));
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
               employee_ID = rs.getInt("employee_ID");
               project_ID = rs.getInt("project_ID");
               project_type = rs.getString("project_type");
               project_status = rs.getString("project_status");
               client = rs.getString("client");
            }
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    };
    
    
     public static void main(String args[]){
        
        projects p = new projects();
        
     
    }
}
