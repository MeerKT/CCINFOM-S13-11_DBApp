/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeemanagement;

import java.time.*;
import java.sql.*;
import java.util.*;

/**
 *
 * @author katie
 */
public class employee_documents {
    // Fields
    public int          employee_ID;
    public int          document_ID;
    public String       document_type;
    public String       document_status;
    public LocalDate    submission_date;
    public LocalDate    expiry_date;
    
    //list of employees
    public ArrayList<Integer> employee_IDList = new ArrayList<>();
    public ArrayList<Integer> document_IDList = new ArrayList<>();
    public ArrayList<String> document_typeList = new ArrayList<>();
    public ArrayList<String> document_statusList = new ArrayList<>();
    public ArrayList<LocalDate> submission_dateList = new ArrayList<>();
    public ArrayList<LocalDate> expiry_dateList = new ArrayList<>();
    
    public employee_documents(){}
    
    
    public int register_employeedoc(){
        
        try {
            Connection  conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/enrolldb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678&useSSL=false"); 
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO employee_documents (employee_ID, document_ID, document_type, document_status, submission_date, expiry_date) VALUES(?,?,?,?,?,?)");
            pstmt.setInt(1,employee_ID);
            pstmt.setInt(2,document_ID);
            pstmt.setString(3,document_type);
            pstmt.setString(4, document_status);
            pstmt.setDate(5,java.sql.Date.valueOf(submission_date));
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    };
    
    
    public int view_docs(){
        
        try {
            Connection  conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/enrolldb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678&useSSL=false"); 
            PreparedStatement pstmt = conn.prepareStatement("SELECT document_ID, document_type, document_status FROM employee_docs WHERE document_ID =?");
            pstmt.setInt(1,document_ID);
            pstmt.setString(2,document_type);
            pstmt.setString(3,document_status);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
               employee_ID = rs.getInt("employee_ID");
               document_type = rs.getString("document_type");
               document_status = rs.getString("document_status");
            }
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    };
    
    public static void main(String args[]){
        
        employee_documents ed = new employee_documents();
        
     
    }
}
