package employeemanagement;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author katie
 */
import java.time.*;
import java.sql.*;
import java.util.*;

public class employee_records {
    // Fields
    public int          employee_ID;
    public String       first_name;
    public String       last_name;
    public String       gender;
    public String       department_name;
    public String       position_type;
    public int          years_of_experience;
    public String       education;
    public LocalTime    check_in_time;    
    public LocalTime    check_out_time;   
    public LocalDate    termination_date; 
    public LocalDate   hire_date;        
    
    //list of employees
    public ArrayList<Integer> employee_IDList = new ArrayList<>();
    public ArrayList<String> first_nameList = new ArrayList<>();
    public ArrayList<String> last_nameList = new ArrayList<>();
    public ArrayList<String> genderList = new ArrayList<>();
    public ArrayList<String> department_nameList = new ArrayList<>();
    public ArrayList<String> position_typeList = new ArrayList<>();
    public ArrayList<Integer> years_of_experienceList = new ArrayList<>();
    public ArrayList<String> educationList = new ArrayList<>();
    public ArrayList<LocalTime> check_in_timeList = new ArrayList<>();
    public ArrayList<LocalTime> check_out_timeList = new ArrayList<>();
    public ArrayList<LocalDate> termination_dateList = new ArrayList<>();
    public ArrayList<LocalDate> hire_dateList = new ArrayList<>();
    
    public employee_records(){}
    public int hire_employee() {
        try{
           Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedb?useTimezone=true&serverTimezone=UTC&user=root&password=Sweetmochi*2003");
           System.out.println("Connection Successful!");
           
           PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(employee_ID) + 1 FROM employee_records");
           ResultSet rst = pstmt.executeQuery();
           while(rst.next()){
               employee_ID = rst.getInt("newID");
           }
           pstmt = conn.prepareStatement("INSERT INTO employee_records "
                   + "(employee_ID, first_name, last_name, gender, department_name, position_type, years_of_experience)"
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)");
           pstmt.setInt(1, employee_ID);                    
           pstmt.setString(2, first_name);                  
           pstmt.setString(3, last_name);                   
           pstmt.setString(4, gender);                      
           pstmt.setString(5, department_name);             
           pstmt.setString(6, position_type);               
           pstmt.setInt(7, years_of_experience);            
           pstmt.setString(8, education);                   
           pstmt.setTime(9, java.sql.Time.valueOf(check_in_time)); 
           pstmt.setTime(10, java.sql.Time.valueOf(check_in_time)); 
           pstmt.setDate(11, java.sql.Date.valueOf(termination_date)); 
           pstmt.setDate(12, java.sql.Date.valueOf(hire_date)); 
    
           
           pstmt.executeUpdate();
           pstmt.close();
           conn.close();
           return 1;
           
        }catch(SQLException e){
          System.out.println(e.getMessage());
        }
        
        return 0;
    };
    
    public int transfer_employee(){
        
        try {
            Connection  conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/enrolldb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678&useSSL=false"); 
            PreparedStatement pstmt = conn.prepareStatement("UPDATE employee_records SET employee_ID = ?, first_name = ?, last_name = ?, department_name = ? WHERE employee_ID = ? AND first_name = ? AND last_name = ? AND department_name = ?");
            pstmt.setInt(1,employee_ID);
            pstmt.setString(2,first_name);
            pstmt.setString(3,last_name);
            pstmt.setString(4,department_name);
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    };
    
    public int terminate_employee(){
        
        try {
            Connection  conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/enrolldb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678&useSSL=false"); 
            PreparedStatement pstmt = conn.prepareStatement("UPDATE employee_records SET employee_ID = ?, first_name = ?, last_name = ?, termination_date = ? WHERE employee_ID = ? AND first_name = ? AND last_name = ? AND termination_date = ?");
            pstmt.setInt(1,employee_ID);
            pstmt.setString(2,first_name);
            pstmt.setString(3,last_name);
            pstmt.setDate(4, java.sql.Date.valueOf(termination_date));
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    };
    
    public int view_record(){
        
        try {
            Connection  conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/enrolldb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678&useSSL=false"); 
            PreparedStatement pstmt = conn.prepareStatement("SELECT employee_ID, first_name, last_name, termination_date = NULL FROM employee_records WHERE employee_ID =?");
            pstmt.setInt(1,employee_ID);
            pstmt.setString(2,first_name);
            pstmt.setString(3,last_name);
            pstmt.setDate(4, java.sql.Date.valueOf(termination_date));
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                first_name = rs.getString("first_name");
                last_name   = rs.getString("department");
            }
            
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    };
    
    public static void main(String args[]){
        
        employee_records er = new employee_records();
        /*rc.first_name = "Mavis";
        rc.last_name = "Stone";
        rc.gender = "Female";
        rc.department_name = "Engineering";
        rc.position_type = "Developer";
        rc.years_of_experience = 5;
        rc.education = "Bachelor's Degree";
        rc.check_in_time = LocalTime.of(9, 0);
        rc.check_out_time = LocalTime.of(17, 0);
        rc.hire_date = LocalDate.of(2022,12,07);
        rc.termination_date = LocalDate.of(2024,10,05);*/
        

        //rc.hire_employee();
        
    }
}
