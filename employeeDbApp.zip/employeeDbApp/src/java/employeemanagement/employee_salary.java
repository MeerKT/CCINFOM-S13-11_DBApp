/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeemanagement;

import java.time.*;
import java.sql.*;
import java.util.*;


/**
 *
 * @author katie
 */
public class employee_salary {
    // Fields
    public int          employee_ID;
    public int          salary_ID;
    public double       basic_salary;
    public int          bank_account;
    public int          overtime_record;
    public double       taxes;
    public String       benefits;
    
    //list of employees
    public ArrayList<Integer> employee_IDList = new ArrayList<>();
    public ArrayList<Integer> salary_IDList = new ArrayList<>();
    public ArrayList<Double> basic_salaryList = new ArrayList<>();
    public ArrayList<Integer> bank_accountList = new ArrayList<>();
    public ArrayList<Integer> overtime_recordList = new ArrayList<>();
    public ArrayList<Double> taxesList = new ArrayList<>();
    public ArrayList<String> benefitsList = new ArrayList<>();
    
    public int register_salary(){
        
        try {
            Connection  conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/enrolldb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678&useSSL=false"); 
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO employee_salary (employee_ID, salary_ID, basic_salary, bank_account, overtime_record, taxes, benefits) VALUES(?,?,?,?,?,?)");
            pstmt.setInt(1,employee_ID);
            pstmt.setInt(2,salary_ID);
            pstmt.setDouble(3,basic_salary);
            pstmt.setInt(4, bank_account);
            pstmt.setInt(5,overtime_record);
            pstmt.setDouble(6, taxes);
            pstmt.setString(7,benefits);
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    };
    
    public int view_salary(){
        
        try {
            Connection  conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/enrolldb?useTimezone=true&serverTimezone=UTC&user=root&password=12345678&useSSL=false"); 
            PreparedStatement pstmt = conn.prepareStatement("SELECT employee_ID, salary_ID, basic_salary FROM employee_salary WHERE salary_ID =?");
            pstmt.setInt(1,salary_ID);
            pstmt.setDouble(2,basic_salary);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
               employee_ID = rs.getInt("employee_ID");
               salary_ID = rs.getInt("salary_ID");
               basic_salary = rs.getDouble("basic_salary");
            }
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    };
    
    public static void main(String args[]){
        
        employee_salary es = new employee_salary();
        
     
    }
}
