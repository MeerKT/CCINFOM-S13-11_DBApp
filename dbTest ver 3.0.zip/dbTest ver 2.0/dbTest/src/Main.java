import java.util.*;

public class Main {
    public static void main(String[] args) {
        Performance_Review reviewEmployee = new Performance_Review();
        Hiring_Termination_Transfer employeeManagement = new Hiring_Termination_Transfer();
        Scanner scan = new Scanner(System.in);
        employee_salary salaryManager = new employee_salary();
        salaryManager.view_salary();

        //reports
        attendance_report ar = new attendance_report();
        performance_report pr = new performance_report();
        salary_report sr = new salary_report();
        hire_attrition_report hr = new hire_attrition_report();


        }
    }