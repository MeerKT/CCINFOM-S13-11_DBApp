
import java.sql.*;
import java.util.ArrayList;

public class attendance_report {

    private Integer year;
    private Integer month;
    private Integer day;

    private ArrayList<String> employeeNames = new ArrayList<>();
    private ArrayList<String> hireDates = new ArrayList<>();
    private ArrayList<String> terminationDates = new ArrayList<>();
    private ArrayList<Integer> totalHoursWorked = new ArrayList<>();
    private ArrayList<Integer> overtimeHours = new ArrayList<>();
    private ArrayList<Integer> totalLeaves = new ArrayList<>();

    public attendance_report() {
        clearReport();
    }

    // Clear all report data
    public void clearReport() {
        year = null;
        month = null;
        day = null;
        employeeNames.clear();
        hireDates.clear();
        terminationDates.clear();
        totalHoursWorked.clear();
        overtimeHours.clear();
        totalLeaves.clear();
    }

    // Generate the report
    public int generate(Integer year, Integer month, Integer day) {
        this.year = year;
        this.month = month;
        this.day = day;

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedb", "root", "WillKill4QP!");
            System.out.println("Connection Successful!");


            String query =
                    "SELECT er.employee_ID, " +
                            "       CONCAT(er.first_name, ' ', er.last_name) AS complete_name, " +
                            "       DATE(er.hire_date) AS hire_date, " +
                            "       IF(er.termination_date IS NULL, 'Active', DATE(er.termination_date)) AS termination_date, " +
                            "       SUM(TIMESTAMPDIFF(HOUR, er.check_in_time, er.check_out_time)) AS total_hours_worked, " +
                            "       SUM(es.overtime_record) AS overtime_hours, " +
                            "       COUNT(CASE WHEN esc.status_type = 'On Leave' THEN 1 END) AS total_leaves " +
                            "FROM employee_records er " +
                            "LEFT JOIN employee_status_change esc ON er.employee_ID = esc.employee_ID " +
                            "LEFT JOIN employee_salary es ON er.employee_ID = es.employee_ID " +
                            "WHERE (YEAR(er.hire_date) = ? OR ? IS NULL) " +
                            "  AND (MONTH(er.hire_date) = ? OR ? IS NULL) " +
                            "  AND (DAY(er.hire_date) = ? OR ? IS NULL) " +
                            "GROUP BY er.employee_ID, complete_name, hire_date, termination_date " +
                            "ORDER BY hire_date ASC";

            PreparedStatement pstmt = conn.prepareStatement(query);

            // Set the parameters for year, month, and day
            pstmt.setObject(1, year);
            pstmt.setObject(2, year);
            pstmt.setObject(3, month);
            pstmt.setObject(4, month);
            pstmt.setObject(5, day);
            pstmt.setObject(6, day);

            ResultSet rs = pstmt.executeQuery();

            // Clear old data
            clearReport();

            // Fetch and store results
            while (rs.next()) {
                employeeNames.add(rs.getString("complete_name"));
                hireDates.add(rs.getString("hire_date"));
                terminationDates.add(rs.getString("termination_date"));
                totalHoursWorked.add(rs.getInt("total_hours_worked"));
                overtimeHours.add(rs.getInt("overtime_hours"));
                totalLeaves.add(rs.getInt("total_leaves"));
            }

            rs.close();
            pstmt.close();
            conn.close();

            return 1; // Success
        } catch (SQLException e) {
            System.out.println("Error generating report: " + e.getMessage());
            return 0; // Failure
        }
    }

    // Print the report
    public void printReport() {
        System.out.println("Attendance Report for Year: " + (year == null ? "All" : year) +
                ", Month: " + (month == null ? "All" : month) +
                ", Day: " + (day == null ? "All" : day));
        System.out.println("================================================================================");
        System.out.printf("%-30s %-15s %-15s %-15s %-15s %-15s%n",
                "Employee Name", "Hire Date", "Termination", "Hours Worked", "Overtime", "Leaves");
        System.out.println("--------------------------------------------------------------------------------");

        for (int i = 0; i < employeeNames.size(); i++) {
            System.out.printf("%-30s %-15s %-15s %-15d %-15d %-15d%n",
                    employeeNames.get(i),
                    hireDates.get(i),
                    terminationDates.get(i),
                    totalHoursWorked.get(i),
                    overtimeHours.get(i),
                    totalLeaves.get(i)
            );
        }
    }

    // Main method to test the report
    public static void main(String[] args) {
        attendance_report ar = new attendance_report ();

        // Example: Generate report for November 2024
        if (ar.generate(2024, 11, null) == 1) {
            ar.printReport();
        } else {
            System.out.println("Failed to generate the report.");
        }
    }
}
