import java.util.*;

public class Main {
    public static void main(String[] args) {
        Hiring_Termination_Transfer test = new Hiring_Termination_Transfer();
        Scanner scan = new Scanner(System.in);

        test.hire_employee();
        test.transfer_employee();
        }
    }