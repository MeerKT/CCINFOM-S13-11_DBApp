import java.util.*;

public class Main {
    public static void main(String[] args) {
        Performance_Review reviewEmployee = new Performance_Review();
        Hiring_Termination_Transfer employeeManagement = new Hiring_Termination_Transfer();
        Scanner scan = new Scanner(System.in);
        employee_salary salaryManager = new employee_salary();
        salaryManager.view_salary();

        }
    }